#!/usr/bin/ruby
# encoding: utf-8
### package: sample 
### author mikimiku
### memo: 一行目、linux実行プログラムパス、二行目文字コード
### 
### usage(実行例): ./sendmail.rb body.txt attachfile 
### ARGV[0]: body.txt メール本文テキストファイル
### ARGV[1]: attachfile 添付ファイル
### 
### 

# メールライブラリの読み込み
require "mail"
# rubyライブラリの読み込み
require "date"

# パラメータチェック
unless ARGV.length == 2 
   puts "パラメータは2つとし、一つ目が本文、二つめが添付ファイルとなります。"
   exit(1) 
end

# メール本文に利用するテキストファイルを指定
bodytext = ARGV[0]

# メール本文テキストファイルが存在しない場合は、
# エラーメッセージを出力し、処理終了
if FileTest.exist?(bodytext) then
   
else
   puts "指定したメール本文テキストファイル#{bodytext}が存在しません。"
   exit(1) 
end

# メール本文に添付するファイルを指定
attachfile = ARGV[1]

# メール本文に添付するファイルが存在しない場合は、
# エラーメッセージを表示し、処理終了
if FileTest.exist?(attachfile) then
   
else
   puts "指定した添付ファイル#{attachfile}が存在しません。"
   exit(1) 
end

# mail送信情報を設定
today = Date.today.strftime("%Y%m%d")
mail = Mail.new do
    # 送信元メールアドレス
    from    "8972xbea@jcom.zaq.ne.jp"
    # 送信先メールアドレス
    to      "yoshitaka_8an9drums@msn.com"
    # メール件名
    subject "report-" << today
    # メール本文(テキストファイルの内容を使用)
    body    File.read(bodytext)
    # 添付ファイル
    add_file attachfile
end

# mail送信の設定
mail.delivery_method(
    # SMTPサーバを指定してメールを送信する
    :smtp,
    # SMTPサーバ
    address:        "smtpa.jcom.zaq.ne.jp",
    # SMTPサーバのポート番号
    port:           465,
    # 送信ドメイン名
    domain:         "localhost.localdomain",
    # 認証:ログイン認証
    authentication: :login,
    # 認証ユーザ名
    user_name:      "8972xbea@jcom.zaq.ne.jp",
    # 認証パスワード名
    password:       "54P4ej4b",
    # SSLによる暗号化を有効
    ssl:            true,
    # 自動的にSSLを開始する 
    enable_starttls_auto: true
)

# mail送信を実行
mail.deliver


