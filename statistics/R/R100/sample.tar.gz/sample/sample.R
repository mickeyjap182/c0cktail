#!/usr/bin/Rscript
### レストラン集計データ検証 ####
# author mikimiku
# #←これはコメントです
# プログラム実行はこのファイルの下の方から開始されます
#################################

require(grDevices)
require(graphics)

# 相関分析関数
correl <- function(retdata, i, msg) {
  # 相関分析
  report <- cor(retdata)
  ### 相関分析結果が「高い相関あり(0.7以上1.0未満)」となるものを表示###
  # 相関分析データ1件ずつ抽出し、高い相関のデータを抽出する
  for(k in 1:nrow(report)) {
    
    # 高い相関のデータであれば内部の処理を行う
    if (report[k] >= 0.7 & report[k] < 1) {
      # 相関が高い旨のメッセージを表示する
      print(gsub("%s%", i, msg))
      # 相関状況のデータを表示する
      print(report[report[k] >= 0.7 & report[k] < 1,])
      break
    }
  }
}

# グラフの色を取得する関数
getcolors <- function() {
   return(
     c(
       "green",
       "blue",
       "red",
       "yellow",
       "orange",
       "brown",
       "pink",
       "magenta",
       "lightblue",
       "lightgreen",
       "black",
       "violet"
     )
   )
}

# 平均値グラフ描画関数
draw <- function(retdata, i, msg) {
  # 平均値を算出
  line <- colMeans(retdata)
  # グラフの色を取得
  cols = getcolors()
  # グラフを描画
  lines(line, type="l", col=cols[i])

}

# メイン処理関数
main <- function(date) {

  # 処理日に前日日付のcsv(comma separated value=カンマ区切り)データファイルを分析結果対象とする
  reportymd <- format(date - 1, '%Y%m%d')
  reportym <- format(date - 1, '%Y%m')
  # paste0で現在のディレクトリからのファイルパスを整形する(例:./input/201505/restaurant-20150528.csv)
  inputfilepath <- paste0("./input/", reportym, "/restaurant-", reportymd, ".csv")

  # 対象データのcsvファイルがなければ処理中断
  if(file.access(inputfilepath) != 0) {
    warning(paste(inputfilepath, "が存在しないため、データ分析処理を中断しました。", sep=""))
  }

  ### 対象データのcsvファイル取り込み###
  # 文字コードUTF-8でファイルを読み込む
  fp <- file(inputfilepath, encoding="UTF-8")
  # 項目ヘッダー行が先頭に存在し、","(カンマ)区切りのcsvファイルとして、データフレームとして取り込む
  data <- read.csv(fp, header=T, sep=",")

  # 比較を容易にするために、日付フォーマットを文字列型に変換
  data[1] <- apply(data[1], 1,  function(x) {return(format(as.Date(x) , "%Y/%m/%d"))})

  # グラフ描画設定(ping画像ファイルデバイスオープン)
  png(paste0("./report/",reportym, "/", reportymd , "-report.png"), width = 400, height = 300)

  # グラフ描画の範囲やラベル設定
plot(0, 0, type = "n", xlim = range(1:8), ylim = range(0,110),
     xlab = "1:レストランの集客, 2:サイトG.総PV数, \n3:サイトH.総PV数, 4:サイトT.総PV数", ylab = "平均集客・PV数")

  # 汎用ラベル名称設定ベクトルを作成
  legendlabel <- c()

  ### DMを送った当日ー10日後に集客数が増えているか
  # DM送信日付のベクトルを取得
  dmday <- data[data$DM送信 == 1, ][1]

  # 調査対象は、DM送信日付の翌日から10日後までの日付
  maxday = 10
  afterday <- c(1:maxday)
  tmp <- "afterdm"
  ### DM送信1日後から10日後までのデータについて、来客数と各サイト閲覧の相関を調査 ###
  for (i in 1:length(afterday)) {

    # DMを送った日からプラスi日した日付のベクトルを取得
    tmpday = eval(
      parse(
        text=paste(
          tmp, i, " <- c(apply(dmday, 1,  function(x) {return(format((as.Date(x) + i), '%Y/%m/%d'))}))", sep=""
        )
      )
    )

    # 抽出結果データ格納ベクトルを初期化
    retdata <-c()
    # DMを送信したi日後の日付のデータ(length(tmpday)回DMを送信したと仮定)を取得する
    for(j in 1:length(tmpday)) {
      # DMを送信したi日後の日付データの集客とサイト訪問数を1件抽出する
      tmpdata <-  data[data$日付 == tmpday[j], c("レストランの集客","サイトG.総PV数", "サイトH.総PV数", "サイトT.総PV数") ]
      # 行列retdataに、抽出したデータを追加する 
      retdata <- merge(retdata, tmpdata, all=TRUE)
    }

    # DMを送信したi日後のデータに対して、集客とサイト訪問数の相関分析を実行する
    msg <- "=====DM送信 %s% 日後のサイト閲覧と客数における相関====="
    # このプログラムファイル上で定義した、自作関数correl()関数を呼び出す
    correl(retdata, i, msg)

    ### 平均集客数とサイト訪問数のグラフ描画を行う ###a
    # 汎用のラベル文字を設定
    msg <- "DM送信%s%日後平均"
    legendlabel[length(legendlabel) + 1] <- gsub("%s%", i, msg)
    # グラフを描画
    draw(retdata, i)

  }
  
  ### 平均集客数とサイト訪問数のグラフ描画を行う ###
  # 平日平均のグラフ描画を行う
  legendlabel[length(legendlabel) + 1] <- "平日平均"
  draw(data[data$土日祝前日 == 0, c("レストランの集客","サイトG.総PV数", "サイトH.総PV数", "サイトT.総PV数") ] , maxday + 1)

  # 土日祝前日平均のグラフ描画を行う
  legendlabel[length(legendlabel) + 1] <- "土日祝前日平均"
  draw(data[data$土日祝前日 == 1, c("レストランの集客","サイトG.総PV数", "サイトH.総PV数", "サイトT.総PV数") ] , maxday + 2)

  # グラフ凡例の描画
  cols <- getcolors()
  legend("bottomright", legend = legendlabel, lty = 1, col = cols)

  # ping画像ファイルデバイスクローズ
  dev.off()

  # グラフィクスのバッファクリア
  graphics.off()
}

### ここから処理開始 ###


# 作業ディレクトリを設定(このプログラムファイルを置いたディレクトリを指定します)
setwd("/home/appleboy/app/sample/")

# 本プログラムの終了時のステータス変数を定義
code <- 1
# tryCatchブロックで通常処理、異常処理、終了処理を設定し、メイン処理を実行します
tryCatch({

  # 自作メイン処理関数のmain()を実行します(main()のパラメータに本日のシステム日付を渡します)
  main(Sys.Date())
  code <- 0
  },
  # stop()で中断が発生したら、実行される処理(変数eは、stop()のメッセージが入ります)
  error = function(e) {
    message(e)           
    code <- 1
  },
  # warning()で警告が発生したら、実行される処理(変数eは、warning()のメッセージが入ります)
  warning = function(e) {
    message(e) 
    code <- 1
  },
  # 最後に必ず実行する処理(error, warningの処理より先に実行されます)
  finnaly = {
  },
  silent = TRUE

)
# 処理終了(セーブをせずに、exitステータスは1:異常、0:正常、終了処理は実行しない)
quit(save = "no", status = code, runLast = FALSE)
