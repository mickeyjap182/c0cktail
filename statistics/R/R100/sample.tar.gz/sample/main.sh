#!/bin/bash

### start.sh 統計解析レポート送信処理
### author mikimiku
### エラーログは標準であれば、/var/log/messagesに出力
###

# 環境変数の設定
export PWD="/home/appleboy/app/sample"

# 処理開始ログを記録
logger -ip user.notice 'program start:main.sh'
### ファイル名を読み取るための日付生成
# yyyymmddで本日の日付を生成
senddate=`date +"%Y%m%d"`

# yyyymmddで前日の日付を生成
datadate=`date --date "-1days" +"%Y%m%d"` 

# ディレクトリ名として使用する、前日のyyyymmを生成
dataym=${datadate:0:6}

# レポート出力先ディレクトリが存在しなければ作成
cur=${PWD}
if [ -e  ${cur}/report/${dataym} ]
then
    logger -ip user.notice 'proccess レポート作成先のディレクトリは存在します。'
else
    mkdir -p ${cur}/report/${dataym} 
fi

# メール本文と添付するレポート画像ファイル名を定義
mailbody="${cur}/report/${dataym}/${datadate}-report.txt"
report="${cur}/report/${dataym}/${datadate}-report.png"

# 解析処理実行、レポート及びメール本文を生成
${PWD}/sample.R 1>${mailbody} 2>&1

# 解析処理でエラーが発生したら、エラーメッセージをログに出力
if [ $? -ne 0 ]
then
    logger -ip user.warn "Error 解析処理でエラーが発生しました。${mailbody}を確認してください。"
fi

# 解析処理でレポート画像ファイルが存在しなければ、エラーメッセージをログにを出力
if [ -e ${report} ]
then
    logger -ip user.notice 'proccess レポートの作成に成功しました。' 
else
    logger -ip user.warn "Error 解析処理でエラーが発生しました。${report}が作成されていません。"
fi

# メール送信処理 
result=`"${PWD}"/sendmail.rb ${mailbody} ${report} 2>&1`

# メール送信処理に失敗すればエラーメッセージをログに出力
if [ $? -ne 0 ]
then
    logger -ip user.warn "Error ${result}"
fi

whoami > tmp.txt
# 処理終了ログ記録
logger -ip user.notice 'program terminate:main.sh'
